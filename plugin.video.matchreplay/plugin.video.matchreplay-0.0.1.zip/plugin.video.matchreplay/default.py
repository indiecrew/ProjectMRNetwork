import urllib, urllib2, re, cookielib, os.path, sys, socket
import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs, utils, favorites

import premierleague, mlb, nba, nfl, nhl, prugby, wten
# import cleague, eleague, laliga, bundesliga, seriea, ligue1

socket.setdefaulttimeout(60)

xbmcplugin.setContent(utils.addon_handle, 'movies')
addon = xbmcaddon.Addon(id=utils.__scriptid__)

progress = utils.progress
dialog = utils.dialog

imgDir = utils.imgDir
rootDir = utils.rootDir


def INDEX():
    utils.addDir('[COLOR grey]Premier League[/COLOR]','',10,os.path.join(imgDir, 'PremierLeague.png'),'')
    # utils.addDir('[COLOR grey]La Liga[/COLOR]','',15,os.path.join(imgDir, 'LaLiga.png'),'')
    # utils.addDir('[COLOR grey]Bundesliga[/COLOR]','',20,os.path.join(imgDir, 'Bundesliga.png'),'')
    # utils.addDir('[COLOR grey]Serie A[/COLOR]','',25,os.path.join(imgDir, 'SerieA.png'),'')
    # utils.addDir('[COLOR grey]Ligue 1[/COLOR]','',30,os.path.join(imgDir, 'Ligue1.png'),'')
    # utils.addDir('[COLOR grey]UEFA Champions League[/COLOR]','',35,os.path.join(imgDir, 'ChampionsLeague.png'),'')
    # utils.addDir('[COLOR grey]UEFA Europa League[/COLOR]','',40,os.path.join(imgDir, 'EuropaLeague.png'),'')
    utils.addDir('[COLOR grey]National Football League[/COLOR]','',60,os.path.join(imgDir, 'nfl.png'),'')
    utils.addDir('[COLOR grey]National Basketball Association[/COLOR]','',65,os.path.join(imgDir, 'nba.png'),'')
    utils.addDir('[COLOR grey]Major League Baseball[/COLOR]','',70,os.path.join(imgDir, 'mlb.png'),'')
    utils.addDir('[COLOR grey]National Hockey League[/COLOR]','',75,os.path.join(imgDir, 'nhl.png'),'')
    utils.addDir('[COLOR grey]Premiership Rugby[/COLOR]','',80,os.path.join(imgDir, 'PremiershipRugby.png'),'')
    # utils.addDir('[COLOR grey]Women Tennis Association[/COLOR]','',85,os.path.join(imgDir, 'WomenTennis.png'),'')
    utils.addDir('[COLOR=900C3F]---[/COLOR]','','',os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR grey]Favourites[/COLOR]: [COLOR=FFED186A]My List[/COLOR]','',901,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR grey]Twitter[/COLOR]: [COLOR=FFED186A]@MRNetworkTV[/COLOR]','','',os.path.join(rootDir, 'icon.png'),'')
    xbmcplugin.endOfDirectory(utils.addon_handle)


def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = getParams()
url = None
name = None
mode = None
img = None
page = 1
fav = None
favmode = None
channel = None
keyword = None


try: url = urllib.unquote_plus(params["url"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: mode = int(params["mode"])
except: pass
try: page = int(params["page"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass
try: fav = params["fav"]
except: pass
try: favmode = int(params["favmode"])
except: pass
try: channel = int(params["channel"])
except: pass
try: keyword = urllib.unquote_plus(params["keyword"])
except: pass


if mode is None: INDEX()

elif mode == 10: premierleague.Main()
elif mode == 11: premierleague.List(url)
elif mode == 12: premierleague.Playvid(url, name)
elif mode == 13: premierleague.Search(url, keyword)
elif mode == 14: premierleague.List2(url, name)

elif mode == 15: laliga.Main()
elif mode == 16: laliga.List(url)
elif mode == 17: laliga.Playvid(url, name)
elif mode == 18: laliga.Search(url, keyword)

elif mode == 20: bundesliga.Main()
elif mode == 21: bundesliga.List(url)
elif mode == 22: bundesliga.Playvid(url, name)
elif mode == 23: bundesliga.Search(url, keyword)

elif mode == 25: seriea.Main()
elif mode == 26: seriea.List(url)
elif mode == 27: seriea.Playvid(url, name)
elif mode == 28: seriea.Search(url, keyword)

elif mode == 30: ligue1.Main()
elif mode == 31: ligue1.List(url)
elif mode == 32: ligue1.Playvid(url, name)
elif mode == 33: ligue1.Search(url, keyword)

elif mode == 35: cleague.Main()
elif mode == 36: cleague.List(url)
elif mode == 37: cleague.Playvid(url, name)
elif mode == 38: cleague.Search(url, keyword)

elif mode == 40: eleague.Main()
elif mode == 41: eleague.List(url)
elif mode == 42: eleague.Playvid(url, name)
elif mode == 43: eleague.Search(url, keyword)

elif mode == 60: nfl.Main()
elif mode == 61: nfl.List(url)
elif mode == 62: nfl.Playvid(url, name)
elif mode == 63: nfl.Search(url, keyword)

elif mode == 65: nba.Main()
elif mode == 66: nba.List(url)
elif mode == 67: nba.Playvid(url, name)
elif mode == 68: nba.Search(url, keyword)

elif mode == 70: mlb.Main()
elif mode == 71: mlb.List(url)
elif mode == 72: mlb.Playvid(url, name)
elif mode == 73: mlb.Search(url, keyword)

elif mode == 75: nhl.Main()
elif mode == 76: nhl.List(url)
elif mode == 77: nhl.Playvid(url, name)
elif mode == 78: nhl.Search(url, keyword)

elif mode == 80: prugby.Main()
elif mode == 81: prugby.List(url)
elif mode == 82: prugby.Playvid(url, name)
elif mode == 83: prugby.Search(url, keyword)

elif mode == 85: wten.Main()
elif mode == 86: wten.List(url)
elif mode == 87: wten.Playvid(url, name)
elif mode == 88: wten.Search(url, keyword)

elif mode == 900: favorites.Favorites(fav,favmode,name,url,img)
elif mode == 901: favorites.List()
elif mode == 902: utils.newSearch(url, channel)
elif mode == 903: utils.clearSearch()

xbmcplugin.endOfDirectory(utils.addon_handle)