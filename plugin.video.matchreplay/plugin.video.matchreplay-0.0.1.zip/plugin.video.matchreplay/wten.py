import urllib, urllib2, re, cookielib, os.path, sys, socket
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

import utils


def Main():
    utils.addDir('[COLOR=FFED186A]Women\'s Tennis Association[/COLOR] | [COLOR white]International[/COLOR]','','',os.path.join(utils.imgDir, 'WomenTennis.png'),'')
    utils.addDir('[COLOR grey]WTA Luxembourg 2016[/COLOR]','plugin://plugin.video.youtube/play/?playlist_id=PLjV8PbU_uZLNmFD8TDwFpYFAhPf2DfVNo',87,'','')
    xbmcplugin.endOfDirectory(utils.addon_handle)

def Playvid(url, name):
    utils.PLAYVIDEO(url, name)
