import urllib, urllib2, re, cookielib, os.path, sys, socket
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

import utils


def Main():
    utils.addDir('[COLOR lime]Eredivisie[/COLOR] | [COLOR white]Netherlands[/COLOR]','','',os.path.join(utils.imgDir, 'Eredivisie.png'),'')
    List('http://www.footballreplay.net/netherlands-eredivisie/')
    xbmcplugin.endOfDirectory(utils.addon_handle)


def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        utils.notify('Oh no','It looks like this website is under maintenance')
        return None
    match = re.compile('<div class="section-title">(.*?)<div id="sidebar">', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    match1 = re.compile(r'<img src="([^"]+)" height="" width="">.*?rel="category tag">(.+?)</a>.*?<h2><a href="([^"]+)" title="([^"]+)">.*?<span class="meta-date">(.+?) (.+?), (.+?)</span>', re.DOTALL | re.IGNORECASE).findall(match)
    for img, game, videopage, name, day, month, year in match1:
        month = utils.cleandate(month)
        date='%s/%s/%s'%(month,day,year)
        name = utils.cleanname(name)
        name='%s %s (%s)'%(date, name, game)
        utils.addLink(name, videopage, 62, img, '')
    try:
        nextp=re.compile("<a class='page-numbers' href='([^']+)'>", re.DOTALL | re.IGNORECASE).findall(match)
        utils.addDir('[COLOR lime]Next Page[/COLOR]', nextp[0], 61,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


def Playvid(url, name):
    utils.PLAYVIDEO(url, name)
