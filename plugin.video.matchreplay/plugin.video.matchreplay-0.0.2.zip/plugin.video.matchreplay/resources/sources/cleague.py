import urllib, urllib2, re, cookielib, os.path, sys, socket
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

import utils


def Main():
    utils.addDir('[COLOR skyblue]Champions League[/COLOR] | [COLOR white]UEFA[/COLOR]','','',os.path.join(utils.imgDir, 'ChampionsLeague.png'),'')
    List('http://livefootballvideo.com/competitions/uefa-champions-league')
    xbmcplugin.endOfDirectory(utils.addon_handle)


def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        utils.notify('Oh no','It looks like this website is under maintenance')
        return None
    match = re.compile('<div id="maincontent">(.*?)<div class="clear">', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    match1 = re.compile(r'div class="cover"><a href="([^"]+)" rel="bookmark" title="([^"]+)"><img src="([^"]+)".*?class="postmetadata longdate" rel=".*?">([^"]+)</p>', re.DOTALL | re.IGNORECASE).findall(match)
    for videopage, name, img, date in match1:
        name = utils.cleanname(name)
        name='%s %s'%(date, name)
        utils.addLink(name, videopage, 37, img, '')
    try:
        nextp=re.compile('<a class="page larger" href="([^"]+)">', re.DOTALL | re.IGNORECASE).findall(match)
        utils.addDir('[COLOR skyblue]Next Page[/COLOR]', nextp[0], 36,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


def Playvid(url, name):
    utils.PLAYVIDEO(url, name)
