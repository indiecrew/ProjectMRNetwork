import urllib, urllib2, re, cookielib, os.path, sys, socket
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

import utils


def Main():
    utils.addDir('[COLOR=FFED186A]Ultimate Fighting Championship[/COLOR] | [COLOR white]International[/COLOR]','','',os.path.join(utils.imgDir, 'ufc.png'),'')
    List('http://www.fullmmavideos.com/category/fightvideos/page/1')
    xbmcplugin.endOfDirectory(utils.addon_handle)


def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        utils.notify('Oh no','It looks like this website is under maintenance')
        return None
    match = re.compile('<div id="td-mega-row">(.*?)<div class="td-next-prev-wrap">', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    match1 = re.compile(r'class="td-module-thumb"><a href="([^"]+)" rel="bookmark" title="([^"]+)".*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(match)
    for videopage, name, img in match1:
        name = utils.cleanname(name)
        utils.addLink(name, videopage, 92, img, '')
    try:
        nextp=re.compile('<link rel="next" href="([^"]+)" />', re.DOTALL | re.IGNORECASE).findall(listhtml)
        utils.addDir('[COLOR=FFED186A]Next Page[/COLOR]', nextp[0], 91,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


def Playvid(url, name):
    utils.PLAYVIDEO(url, name)
