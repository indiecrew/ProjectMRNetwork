import xbmcaddon

MainBase = 'http://goo.gl/xZLSvx'
addon = xbmcaddon.Addon('plugin.video.MyAnimasi')